
class NotRelatedToAnyInvoice(Exception):
    pass