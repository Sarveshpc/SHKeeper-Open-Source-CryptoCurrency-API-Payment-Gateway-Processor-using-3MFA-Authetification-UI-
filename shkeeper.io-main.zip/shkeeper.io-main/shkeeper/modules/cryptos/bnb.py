from shkeeper.modules.classes.bnb import Bnb


class bnb(Bnb):
    def __init__(self):
        self.crypto="BNB"


    def getname(self):
        return "BNB"

