from shkeeper.modules.classes.xrp import Xrp


class xrp(Xrp):
    def __init__(self):
        self.crypto="XRP"


    def getname(self):
        return "XRP"

